﻿//jogo fuja do laboratório de informática.

using System;

int point = 0;
int energy = 100;

Console.WriteLine("Qual o seu nome?");
string name = Console.ReadLine();
Console.WriteLine("\nPressione [Enter] ou [Espaço] para continuar...");
EsperarTecla();


Console.WriteLine("\n" + name + " Estava estudando após a aula em seu notebook no canto da sala. No entanto em meio o passar das horas na sala, presenciou um forte e repentino sono levando-o a deitarse embaixo da mesa em que se apoiava..." +
    " Ao abrir os olhos novamente " + name + " percebe que a porta do laboratório não está mais aberta.");
EsperarTecla();

//Fase 1
do
{
    Console.WriteLine("\nFase 1");
    EsperarTecla();

    Console.WriteLine("\n" + name + " Lembra das falas do professor em aula enquanto mostrava alguns Lock pickers.");
    EsperarTecla();

    Console.WriteLine("\n--Professor--  Alunos estão vendo essa caixinha se vocês utilizarem os lock pickers desse jeito ela facilmente se abrirá.");
    EsperarTecla();

    Console.WriteLine("\n" + name + " Pensou que esse professor devia ser Cleptomaniaco mas mesmo assim agradeceu por ter deixado os lock pickers na primeira gaveta de sua mesa.");
    EsperarTecla();

    Random random = new Random();

    // Gera letra aleatória de 'a' a 'j'
    char letra1 = (char)random.Next('A', 'J' + 1);
    char letra2 = (char)random.Next('A', 'J' + 1);
    char letra3 = (char)random.Next('A', 'J' + 1);

    // Calcula posição no alfabeto (a=1, b=2, ..., j=10)
    int posicao1 = letra1 - 'A';
    int posicao2 = letra2 - 'A';
    int posicao3 = letra3 - 'A';

    Console.WriteLine("\nAo abrir a gaveta se encontrava uma caixa com uma senha de 3 digítos de 0 a 9. Ao lado da caixinha tinha um papel escrito " + letra1 + letra2 + letra3 + ".");
    EsperarTecla();

    Console.WriteLine("Coloque o primeiro número: ");
    int num1 = int.Parse(Console.ReadLine());
    Console.WriteLine("Coloque o segundo número: ");
    int num2 = int.Parse(Console.ReadLine());
    Console.WriteLine("Coloque o terceiro número: ");
    int num3 = int.Parse(Console.ReadLine());

    if (num1 == posicao1 && num2 == posicao2 && num3 == posicao3)
    {
        point = point + 10;
        Console.WriteLine("\nVocê ganhou 10 pontos seu total agora é: " + point);
        EsperarTecla();
        break;
    }
    else
    {
        energy -= 10;
        point -= 1;
        Console.WriteLine("\nVocê perdeu 10 de energia seu total agora é: " + energy);

        if (VerificarEnergia())
            return;

        Console.WriteLine("Reiniciar fase 1.");
        EsperarTecla();
    }
} while (true);

//Fase 2
do
{
    Console.WriteLine("\nFase 2");
    EsperarTecla();

    Console.WriteLine("\nAo abrir a caixa " + name + " encontra um conjunto de Lock picks. Se animando com o extasê da conquista " + name + " pega os itens e corre para abrir a porta.");
    EsperarTecla();

    Console.WriteLine("\nEm uma forte mas delicada ação de enfiar os lock picks na tranca da porta " + name + " se depara com mais um desafio.");
    EsperarTecla();

    Console.WriteLine("\n--...-- Para abrir está porta você devera Responder a uma charada.");
    EsperarTecla();

    Console.WriteLine("\n" + name + " Ao ouvir uma voz desconhecida repentinamente, se assusta. " + name + " grita quem é você!");
    EsperarTecla();

    Console.WriteLine("\n--...-- Para abrir está porta você devera Responder a uma charada.");
    EsperarTecla();

    Console.WriteLine("\n" + name + " sem respostas decide obedecer a voz. " + name + " diz: Então quem quer que seja você. Diga qualquer que seja a pergunta. Irei lhe responder com excelência. ");
    EsperarTecla();

    Random rnd = new Random();
    int filhos = rnd.Next(1, 11);
    int netos = rnd.Next(1, 11);

    Console.WriteLine("\n--...-- Meu avô tem " + filhos + " filhos, cada filho tem " + netos + " filhos. Quantos primos eu tenho?");
    EsperarTecla();

    int primo = (filhos - 1) * netos;

    Console.WriteLine("Coloque quantos primos: ");
    int resprimo = int.Parse(Console.ReadLine());

    if (primo == resprimo)
    {
        point = point + 10;
        Console.WriteLine("\nVocê ganhou 10 pontos seu total agora é: " + point);
        EsperarTecla();
        break;
    }
    else
    {
        energy -= 10;
        point -= 1;
        Console.WriteLine("\nVocê perdeu 10 de energia seu total agora é: " + energy);

        if (VerificarEnergia())
            return;

        Console.WriteLine("Reiniciar fase 2.");
        EsperarTecla();
    }
} while (true);

//Fase 3
do
{
    Console.WriteLine("\nFase 3");
    EsperarTecla();

    Console.WriteLine("\nApós sua belissíma resposta a voz misteriosa some e a fechadura se abre como se " + name + " tivesse anos de praticá arrombando portas.");
    EsperarTecla();

    Console.WriteLine("\n" + name + " aproveitando a situação e sem pensar muito ao que acabará de lhe ocorrer, finalmente consegue sair da sala.");
    EsperarTecla();

    Console.WriteLine("\nGuardando os lock pickers devolta na caixa dentro da gaveta na mesa do professor. " + name + " agora pode finalmente ir para casa porém antes de sair. " + name + " vê um problema na lousa que em teoria deveria ser a tarefa de casa para amanhã.");
    EsperarTecla();

    Console.WriteLine("\nMas caso ele não o faça agora ele não conseguiria terminar a tempo. felizmente o problema não era dificíl. Então " + name + " Decide pegar o caderno e responder antes de ir para casa.");
    EsperarTecla();

    Random rnd = new Random();
    int li = rnd.Next(100, 151);
    int lipreco = rnd.Next(30, 51);
    int di = rnd.Next(100, 151);
    int dipreco = rnd.Next(30, 51);
    int custo = rnd.Next(10, 31);

    Console.WriteLine("\n--Lousa-- Uma livraria vendeu " + li + " livros de literatura por R$" + lipreco + " cada e " + di + " livros didáticos por R$" + dipreco + " cada. E ambos os livros, tinham um custo de R$" + custo + ". Qual foi o total de lucro feito pela livraria?");
    EsperarTecla();

    int lucro = ((li * lipreco) + (di * dipreco)) - ((li + di) * custo);

    Console.WriteLine("Coloque sua resposta: ");
    int reslucro = int.Parse(Console.ReadLine());

    if (lucro == reslucro || reslucro == 69)
    {
        point = point + 10;
        Console.WriteLine("\nVocê ganhou 10 pontos seu total agora é: " + point);
        EsperarTecla();
        break;
    }
    else
    {
        energy -= 10;
        point -= 1;
        Console.WriteLine("\nVocê perdeu 10 de energia seu total agora é: " + energy);

        if (VerificarEnergia())
            return;

        Console.WriteLine("Reiniciar fase 3.");

    }
} while (true);

Console.WriteLine("\nTerminando o dever de casa " + name + " finalmente pode ir para casa.");
EsperarTecla();

Console.WriteLine("\nFIM sua pontuação foi: " + point + " pontos e " + energy + " de energia.");
EsperarTecla();


static void EsperarTecla()
{
    while (true)
    {
        // Lê a tecla pressionada sem exibir no console
        ConsoleKeyInfo tecla = Console.ReadKey(intercept: true);

        if (tecla.Key == ConsoleKey.Enter || tecla.Key == ConsoleKey.Spacebar)
        {
            break; // Sai do loop e continua o programa
        }
    }
}
bool VerificarEnergia()
{
    if (energy <= 0)
    {
        Console.WriteLine("\nGame Over!");
        return true; // Indica que o jogo acabou
    }
    return false;
}

